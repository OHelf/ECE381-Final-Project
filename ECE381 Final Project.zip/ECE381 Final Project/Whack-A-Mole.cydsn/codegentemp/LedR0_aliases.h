/*******************************************************************************
* File Name: LedR0.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LedR0_ALIASES_H) /* Pins LedR0_ALIASES_H */
#define CY_PINS_LedR0_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define LedR0_0			(LedR0__0__PC)
#define LedR0_0_PS		(LedR0__0__PS)
#define LedR0_0_PC		(LedR0__0__PC)
#define LedR0_0_DR		(LedR0__0__DR)
#define LedR0_0_SHIFT	(LedR0__0__SHIFT)
#define LedR0_0_INTR	((uint16)((uint16)0x0003u << (LedR0__0__SHIFT*2u)))

#define LedR0_INTR_ALL	 ((uint16)(LedR0_0_INTR))


#endif /* End Pins LedR0_ALIASES_H */


/* [] END OF FILE */
