/*******************************************************************************
* File Name: LedR0.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LedR0_H) /* Pins LedR0_H */
#define CY_PINS_LedR0_H

#include "cytypes.h"
#include "cyfitter.h"
#include "LedR0_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} LedR0_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   LedR0_Read(void);
void    LedR0_Write(uint8 value);
uint8   LedR0_ReadDataReg(void);
#if defined(LedR0__PC) || (CY_PSOC4_4200L) 
    void    LedR0_SetDriveMode(uint8 mode);
#endif
void    LedR0_SetInterruptMode(uint16 position, uint16 mode);
uint8   LedR0_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void LedR0_Sleep(void); 
void LedR0_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(LedR0__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define LedR0_DRIVE_MODE_BITS        (3)
    #define LedR0_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - LedR0_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the LedR0_SetDriveMode() function.
         *  @{
         */
        #define LedR0_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define LedR0_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define LedR0_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define LedR0_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define LedR0_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define LedR0_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define LedR0_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define LedR0_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define LedR0_MASK               LedR0__MASK
#define LedR0_SHIFT              LedR0__SHIFT
#define LedR0_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in LedR0_SetInterruptMode() function.
     *  @{
     */
        #define LedR0_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define LedR0_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define LedR0_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define LedR0_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(LedR0__SIO)
    #define LedR0_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(LedR0__PC) && (CY_PSOC4_4200L)
    #define LedR0_USBIO_ENABLE               ((uint32)0x80000000u)
    #define LedR0_USBIO_DISABLE              ((uint32)(~LedR0_USBIO_ENABLE))
    #define LedR0_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define LedR0_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define LedR0_USBIO_ENTER_SLEEP          ((uint32)((1u << LedR0_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << LedR0_USBIO_SUSPEND_DEL_SHIFT)))
    #define LedR0_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << LedR0_USBIO_SUSPEND_SHIFT)))
    #define LedR0_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << LedR0_USBIO_SUSPEND_DEL_SHIFT)))
    #define LedR0_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(LedR0__PC)
    /* Port Configuration */
    #define LedR0_PC                 (* (reg32 *) LedR0__PC)
#endif
/* Pin State */
#define LedR0_PS                     (* (reg32 *) LedR0__PS)
/* Data Register */
#define LedR0_DR                     (* (reg32 *) LedR0__DR)
/* Input Buffer Disable Override */
#define LedR0_INP_DIS                (* (reg32 *) LedR0__PC2)

/* Interrupt configuration Registers */
#define LedR0_INTCFG                 (* (reg32 *) LedR0__INTCFG)
#define LedR0_INTSTAT                (* (reg32 *) LedR0__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define LedR0_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(LedR0__SIO)
    #define LedR0_SIO_REG            (* (reg32 *) LedR0__SIO)
#endif /* (LedR0__SIO_CFG) */

/* USBIO registers */
#if !defined(LedR0__PC) && (CY_PSOC4_4200L)
    #define LedR0_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define LedR0_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define LedR0_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define LedR0_DRIVE_MODE_SHIFT       (0x00u)
#define LedR0_DRIVE_MODE_MASK        (0x07u << LedR0_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins LedR0_H */


/* [] END OF FILE */
