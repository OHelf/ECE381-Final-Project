/*******************************************************************************
* File Name: LedR2.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LedR2_ALIASES_H) /* Pins LedR2_ALIASES_H */
#define CY_PINS_LedR2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define LedR2_0			(LedR2__0__PC)
#define LedR2_0_PS		(LedR2__0__PS)
#define LedR2_0_PC		(LedR2__0__PC)
#define LedR2_0_DR		(LedR2__0__DR)
#define LedR2_0_SHIFT	(LedR2__0__SHIFT)
#define LedR2_0_INTR	((uint16)((uint16)0x0003u << (LedR2__0__SHIFT*2u)))

#define LedR2_INTR_ALL	 ((uint16)(LedR2_0_INTR))


#endif /* End Pins LedR2_ALIASES_H */


/* [] END OF FILE */
